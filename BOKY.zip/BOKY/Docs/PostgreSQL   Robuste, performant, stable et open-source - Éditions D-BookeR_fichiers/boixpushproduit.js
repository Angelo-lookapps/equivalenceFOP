
// Serialscroll exclude option bug ?
function serialScrollFixLock(event, targeted, scrolled, items, position)
{
	serialScrollNbImages = $('#boixpushproduits .block_content li:visible').length;
	serialScrollNbImagesDisplayed = 1;

	var leftArrow = position == 0 ? true : false;
	var rightArrow = position + serialScrollNbImagesDisplayed >= serialScrollNbImages ? true : false;

	$('a#featuredPrev').css('cursor', leftArrow ? 'default' : 'pointer').css('display', leftArrow ? 'none' : 'block').fadeTo(0, leftArrow ? 0 : 1);
	$('a#featuredNext').css('cursor', rightArrow ? 'default' : 'pointer').fadeTo(0, rightArrow ? 0 : 1).css('display', rightArrow ? 'none' : 'block');
	return true;
}

//To do after loading HTML
$(document).ready(function()
{
	//init the serialScroll for thumbs
	$('#boixpushproduits .block_content').serialScroll({
		items:'li:visible',
		prev:'a#featuredPrev',
		next:'a#featuredNext',
		axis:'x',
		offset:0,
		start:0,
		stop:true,
		onBefore:serialScrollFixLock,
		duration:700,
		step: 1,
		lazy: true,
		lock: false,
		force:false,
		cycle:false
	});
	var i=$('#boixpushproduits li').length;
	var thumb_width = $('#boixpushproduits ul >li').width()+parseInt($('#boixpushproduits ul >li').css('marginRight'))+2;
	$('#boixpushproduits ul').width((parseInt((thumb_width)* i) + 3) + 'px'); //  Bug IE6, needs 3 pixels more ?
	$('#boixpushproduits .block_content').trigger('goto', 1);// SerialScroll Bug on goto 0 ?
	$('#boixpushproduits .block_content').trigger('goto', 1);

});