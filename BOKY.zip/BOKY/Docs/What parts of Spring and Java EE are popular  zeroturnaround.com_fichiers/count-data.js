var DISQUSWIDGETS;

if (typeof DISQUSWIDGETS != 'undefined') {
    DISQUSWIDGETS.displayCount({"text":{"and":"and","comments":{"zero":"0 Comments","multiple":"{num} Comments","one":"1 Comment"}},"counts":[{"id":"https:\/\/zeroturnaround.com\/rebellabs\/spring-vs-java-ee-survey-results\/","comments":7}]});
}