$(function() {
    var $country = $('#customer-country') || $('#country');
    var $phone = $('#customer-phone') || $('#phone');

    var currentCallingCode = '';

    var updateCallingCode = function(){
        var currentPhoneVal = $phone.val();
        if (currentPhoneVal && currentPhoneVal.length) {
            //some magic to keep the number entered by user by stripping prefix
            //not quite bulletproof but.. will do for now
            if (currentPhoneVal.substr(0, currentCallingCode.length) === currentCallingCode) {
                currentPhoneVal = currentPhoneVal.substr(currentCallingCode.length);
            }
        } else {
            currentPhoneVal = ' ';
        }

        var selectedCountry = $country.find("option:selected").text();
        if (typeof callingCodes !== 'undefined' && typeof callingCodes[selectedCountry] !== 'undefined') {
            currentCallingCode = callingCodes[selectedCountry];
            $phone.val(currentCallingCode + currentPhoneVal);
        }
    };

    if ( !$phone.val() ) {
        updateCallingCode();
    }

    $country.change(function(){
        updateCallingCode();
    });
});
